import java.util.Scanner;
public class GradeMark{
    public static void main (String[]args){
        
        int grade;
        
        Scanner input = new Scanner(System.in);
        
        //user input their mark
        System.out.println("Enter your mark:");
        grade = input.nextInt();
        
        //show their grade
        if (grade >= 70 && grade <= 100)
            System.out.println("Grade = A");
        else if (grade >= 60 && grade <= 69)
            System.out.println("Grade = B");
        else if (grade >= 50 && grade <= 59)
            System.out.println("Grade = C");
        else if (grade >= 45 && grade <= 49)
            System.out.println("Grade = D");
        else if (grade >= 40 && grade <= 44)
            System.out.println("Grade = E");
        else if (grade >= 0 && grade <= 39)
            System.out.println("Grade = FAIL");
        else
            System.out.println("Invalid data");
    }
}
