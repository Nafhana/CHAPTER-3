import java.util.Scanner;

public class PurSys {
    public static void main(String[] args) {
        
        int quantity, smoothie;
        float price = 0, totalPrice, discount = 0;
        char member;
        Scanner input = new Scanner(System.in);
        
        // Display menu
        System.out.println("MENU");
        System.out.println("1. Strawberry Smoothie : RM10");
        System.out.println("2. Blueberry Smoothie : RM10");
        System.out.println("3. Banana Smoothie : RM8");
        System.out.println("4. Mango Smoothie : RM8");
        
        // User enters orders information
        System.out.println("What would you like to order (1-4):");
        smoothie = input.nextInt();
        System.out.println("Enter the smoothie quantity:");
        quantity = input.nextInt();
        
        // Set price for smoothie
        if (smoothie == 1) 
            price = 10;
        else if (smoothie == 2) 
            price = 10;
        else if (smoothie == 3) 
            price = 8;
        else if (smoothie == 4)
            price = 8;
        else {
            System.out.println("Invalid number");
            return;
        }
        
        // Calculate total price
        totalPrice = price * quantity;
        
        // Ask for membership
        System.out.println("Do you have membership? (y/n):");
        member = input.next().charAt(0);
        
        // Membership discount
        if (Character.toLowerCase(member) == 'y') {
            discount = totalPrice * 0.20f;
            totalPrice -= discount;
        }
        
        // Display the order information
        System.out.println("Your order: " + smoothie);
        System.out.println("Price per smoothie: RM" + price);
        System.out.println("Quantity: " + quantity);
        System.out.println("Total price before discount: RM" + (price * quantity));
        if (discount > 0) {
            System.out.println("Membership discount: RM" + discount);
            System.out.println("Price after discount: RM" + totalPrice);
        } else {
            System.out.println("Total price: RM" + totalPrice);
        }
    }
}
