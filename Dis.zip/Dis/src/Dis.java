import java.util.Scanner;

public class Dis {
    public static void main(String[] args) {
        
        String itemName;
        int quantity, colour;
        float price, discountRate = 0, totalPrice, after, discount;
        Scanner input = new Scanner(System.in);
        
        // User enter item's information
        System.out.println("Enter the name of the item :");
        itemName = input.nextLine();
        
        System.out.println("Discount by colours:");
        System.out.println("1. Red : 45%");
        System.out.println("2. Green : 35%");
        System.out.println("3. Blue : 40%");
        System.out.println("4. Yellow : 15%");
        
        System.out.println("Enter the color of the item (1-4):");
        colour = input.nextInt();
        System.out.println("Enter the price :");
        price = input.nextFloat();
        System.out.println("Enter the item quantity :");
        quantity = input.nextInt();
        
        // Set the discount rate based on the color
        switch (colour) {
            case 1:
                discountRate = 45;
                break;
            case 2:
                discountRate = 35;
                break;
            case 3:
                discountRate = 40;
                break;
            case 4:
                discountRate = 15;
                break;
            default:
                System.out.println("Invalid color entered. No discount will be applied.");
                break;
        }
        
        // Calculate total price and the price after discount
        totalPrice = price * quantity;
        discount = (discountRate / 100) * totalPrice;
        after = totalPrice - discount;
        
        // Show all item's information
        System.out.println("Item name: " + itemName);
        System.out.println("Item price: " + price);
        System.out.println("Item quantity: " + quantity);
        System.out.println("Total Price: " + totalPrice);
        System.out.println("Discount rate: " + discountRate + "%");
        System.out.println("Item price after discount: " + after);
        
    }
}

