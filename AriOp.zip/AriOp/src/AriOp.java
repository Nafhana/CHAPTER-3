import java.util.Scanner;
public class AriOp{
    public static void main (String[]args){
        
        char operator;
        float number1, number2, ans, inc1, inc2, dec1, dec2;
        
        Scanner input = new Scanner(System.in);
        
        //select which operator
        System.out.println("addition:A");
        System.out.println("subtraction:B");
        System.out.println("Multiplication:C");
        System.out.println("Division:D");
        System.out.println("Modulus:E");
        System.out.println("Increament:F");
        System.out.println("decreament:G");
        
        System.out.println("choose an operator:");
        operator = input.next().charAt(0);
        
        
        //calculate 2 numbers from chosen operator
        switch(Character.toUpperCase(operator)){
            case 'A' :
            System.out.println("Enter first number");
            number1 = input.nextInt();
            System.out.println("Enter second number");
            number2 = input.nextInt();
            ans = number1 + number2;
            System.out.println("ADDITION:"+ans);
            break;
            case 'B' :
            System.out.println("Enter first number");
            number1 = input.nextInt();
            System.out.println("Enter second number");
            number2 = input.nextInt();
            ans = number1 - number2;
            System.out.println("SUBSTRACTION:"+ans);
            break;
            case 'C' :
            System.out.println("Enter first number");
            number1 = input.nextInt();
            System.out.println("Enter second number");
            number2 = input.nextInt();
            ans = number1 * number2;
            System.out.println("MULTIPLICATION:"+ans);
            break;
            case 'D' :
            System.out.println("Enter first number");
            number1 = input.nextInt();
            System.out.println("Enter second number");
            number2 = input.nextInt();
            ans = number1 / number2;
            System.out.println("DIVISION:"+ans);
            break;
            case 'E' :
            System.out.println("Enter first number");
            number1 = input.nextInt();
            System.out.println("Enter second number");
            number2 = input.nextInt();
            ans = number1 % number2;
            System.out.println("MODULUD:"+ans);
            break;
            case 'F' :
            System.out.println("Enter first number");
            number1 = input.nextInt();
            System.out.println("Enter second number");
            number2 = input.nextInt();
            inc1 = ++number1;
            inc2 = ++number2;
            System.out.println("INCREAMENT FIRST NUMBER:"+inc1);
            System.out.println("INCREAMENT SECOND NUMBER:"+inc2);
            break;
            case 'G' :
            System.out.println("Enter first number");
            number1 = input.nextInt();
            System.out.println("Enter second number");
            number2 = input.nextInt();
            dec1 = --number1;
            dec2 = --number2;
            System.out.println("DECREMENT FIRST NUMBER:"+dec1);
            System.out.println("DECREAMENT SECOND NUMBER:"+dec2);
            break;
            default: System.out.println("Invalid input");
            break;
        }
    }
}

